=== WEB ANKETA 5 - RAVIS ===
Contributors: RAVIS
Donate link: http://example.com/
Tags: anketa, web anketa, dotazovací anketa, wordpress anketa, wordpressweb anketa, anketa na web stránky,
Requires at least: 4.0
Tested up to: 4.8
Requires PHP: 5.6
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

web anketa až s pěti dotazy, minimálně dva dotazy jsou pvinné, libovolný počet anket

== Description ==
Dotazovací anketa na webové stránky až s pěti dotazy. získate zpětnou vazbu navštěvníků vaši web stránek. Zjistěte, co děláte dobře a co špatně. Snadné a rychlé použití. Začněte sbírat cenné odpovědi ještě dnes.


== Installation ==
1. Upload "test-plugin.php" to the "/wp-content/plugins/" directory.
1. Activate the plugin through the "Plugins" menu in WordPress.
1. Place "do_action( 'plugin_name_hook' );" in your templates.

== Frequently Asked Questions ==
= kolik je možné zadat anketních dotazů v jedné anketě? =
maximálně pět.

= kolik je možné vytvořit anket? =
neomezeně.



== Screenshots ==
1. administrace ankety screenshot-1
2. přehled vytvořených anket screenshot-2
3. záznam todazů a odpovědí  screenshot-3
4. vložedí ankety do postraního panelu - sidebaru  screenshot-4

== Changelog ==

= 0.1 =
* Initial release.

== Upgrade Notice ==

= 0.1 = 
aktualizace není nutná.