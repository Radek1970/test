<?php
$logo = (WEB_ANKETA_RAVIS_BASE_URL.'assets/img/logo1.png'); 
//echo $obr;
$verze = "verze 5.1.2" ;

//echo '<h1 class="titul"> <img src="'. $logo.'" alt="" width="130px" height="29px" > Administrace pluginu WEB ANKETA 5 verze 5.1.1xx RAVIS</h1>';    
    
 //require_once(WEB_ANKETA_RAVIS_DIR.'includes/verze_pluginu.php');   
    
?>